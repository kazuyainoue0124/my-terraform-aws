def lambda_handler(event:, context:)
  "Welcome to HN Ruby Digest!"
end
